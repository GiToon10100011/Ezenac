const output = document.querySelector("#output");

const arr = [2, 1, 3, 10];