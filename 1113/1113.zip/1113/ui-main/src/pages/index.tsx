import React from "react";

const Index = () => {
  return <h1>Index</h1>;
};

export default Index;
