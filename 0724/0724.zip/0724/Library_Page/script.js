//Slick Slider
$(".history-slider").slick({
  arrows: false,
  dots : true,
  infinite : true, 
  speed : 300,
  slidesToShow : 4,
  slidesToScroll : 2,
  autoplay: true,
  
});