/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
self["webpackHotUpdate_N_E"]("app/(with-searchbar)/page",{

/***/ "(app-pages-browser)/./src/styles/skeletonStyles/book-item-skeleton.module.css":
/*!*****************************************************************!*\
  !*** ./src/styles/skeletonStyles/book-item-skeleton.module.css ***!
  \*****************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

eval(__webpack_require__.ts("// extracted by mini-css-extract-plugin\nmodule.exports = {\"container\":\"book-item-skeleton_container__eiafG\",\"cover_img\":\"book-item-skeleton_cover_img__lfzHz\",\"info_container\":\"book-item-skeleton_info_container__HxVaW\"};\n    if(true) {\n      // 1732603543058\n      var cssReload = __webpack_require__(/*! ./node_modules/next/dist/compiled/mini-css-extract-plugin/hmr/hotModuleReplacement.js */ \"(app-pages-browser)/./node_modules/next/dist/compiled/mini-css-extract-plugin/hmr/hotModuleReplacement.js\")(module.id, {\"publicPath\":\"/_next/\",\"esModule\":false,\"locals\":true});\n      module.hot.dispose(cssReload);\n      \n    }\n  \nmodule.exports.__checksum = \"92b383b2f6da\"\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwcC1wYWdlcy1icm93c2VyKS8uL3NyYy9zdHlsZXMvc2tlbGV0b25TdHlsZXMvYm9vay1pdGVtLXNrZWxldG9uLm1vZHVsZS5jc3MiLCJtYXBwaW5ncyI6IkFBQUE7QUFDQSxrQkFBa0I7QUFDbEIsT0FBTyxJQUFVO0FBQ2pCO0FBQ0Esc0JBQXNCLG1CQUFPLENBQUMsd01BQW1JLGNBQWMsc0RBQXNEO0FBQ3JPLE1BQU0sVUFBVTtBQUNoQjtBQUNBO0FBQ0E7QUFDQSx5QkFBeUIiLCJzb3VyY2VzIjpbIi9Vc2Vycy90eWxlcmpvbi9FemVuYWMvRXplbmFjLzExMjYvYXBwLXJvdXRlci9zcmMvc3R5bGVzL3NrZWxldG9uU3R5bGVzL2Jvb2staXRlbS1za2VsZXRvbi5tb2R1bGUuY3NzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIGV4dHJhY3RlZCBieSBtaW5pLWNzcy1leHRyYWN0LXBsdWdpblxubW9kdWxlLmV4cG9ydHMgPSB7XCJjb250YWluZXJcIjpcImJvb2staXRlbS1za2VsZXRvbl9jb250YWluZXJfX2VpYWZHXCIsXCJjb3Zlcl9pbWdcIjpcImJvb2staXRlbS1za2VsZXRvbl9jb3Zlcl9pbWdfX2xmekh6XCIsXCJpbmZvX2NvbnRhaW5lclwiOlwiYm9vay1pdGVtLXNrZWxldG9uX2luZm9fY29udGFpbmVyX19IeFZhV1wifTtcbiAgICBpZihtb2R1bGUuaG90KSB7XG4gICAgICAvLyAxNzMyNjAzNTQzMDU4XG4gICAgICB2YXIgY3NzUmVsb2FkID0gcmVxdWlyZShcIi9Vc2Vycy90eWxlcmpvbi9FemVuYWMvRXplbmFjLzExMjYvYXBwLXJvdXRlci9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2NvbXBpbGVkL21pbmktY3NzLWV4dHJhY3QtcGx1Z2luL2htci9ob3RNb2R1bGVSZXBsYWNlbWVudC5qc1wiKShtb2R1bGUuaWQsIHtcInB1YmxpY1BhdGhcIjpcIi9fbmV4dC9cIixcImVzTW9kdWxlXCI6ZmFsc2UsXCJsb2NhbHNcIjp0cnVlfSk7XG4gICAgICBtb2R1bGUuaG90LmRpc3Bvc2UoY3NzUmVsb2FkKTtcbiAgICAgIFxuICAgIH1cbiAgXG5tb2R1bGUuZXhwb3J0cy5fX2NoZWNrc3VtID0gXCI5MmIzODNiMmY2ZGFcIlxuIl0sIm5hbWVzIjpbXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(app-pages-browser)/./src/styles/skeletonStyles/book-item-skeleton.module.css\n"));

/***/ })

});