const changePhone1 = () => {
  // value속성을 통해 phoneValue1의 값을 받아옴
  const phone1 = document.querySelector("#phone1").value;
  // 리얼타임으로 받아오는 것이 아니기에 이벤트 부여
  if (phone1.length === 3) {
    // focus 함수를 통해 커서가 넘어가게됨
    document.querySelector("#phone2").focus();
  }
};
const changePhone2 = () => {
  // value속성을 통해 phoneValue1의 값을 받아옴
  const phone2 = document.querySelector("#phone2").value;
  // 리얼타임으로 받아오는 것이 아니기에 이벤트 부여
  if (phone2.length === 4) {
    // focus 함수를 통해 커서가 넘어가게됨
    document.querySelector("#phone3").focus();
  }
};
const changePhone3 = () => {
  // value속성을 통해 phoneValue1의 값을 받아옴
  const phone1 = document.querySelector("#phone1").value;
  const phone2 = document.querySelector("#phone2").value;
  const phone3= document.querySelector("#phone3").value;
  // 리얼타임으로 받아오는 것이 아니기에 이벤트 부여
  if (phone1.length === 3 && phone2.length === 4 && phone3.length === 4) {
    document.querySelector("#token_button").removeAttribute("disabled");
  } else{
    document.querySelector("#token_button").setAttribute("disabled", true);
  }
};
