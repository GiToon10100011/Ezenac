import React from "react";

const ErrorComponent = () => {
  return <h1>Server Crashed</h1>;
};

export default ErrorComponent;
