import React from "react";

const Home = () => {
  const users: any = [];
  return <h1>{users[0].name}</h1>;
};

export default Home;
