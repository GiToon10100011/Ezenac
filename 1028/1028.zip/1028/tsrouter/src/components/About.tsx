import React from "react";

const About = () => {
  return <div>Hello World!</div>;
};

export default About;
