const test = {
  name: "염동훈",
  major: "computer",
  grade: 2,
  course: ["html", "css", "js"],
  test : {
    title : "자료구조와 알고리즘",
    testWeek : 3
  }
};
