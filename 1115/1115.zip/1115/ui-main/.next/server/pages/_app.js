/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./src/styles/global-layout.module.css":
/*!*********************************************!*\
  !*** ./src/styles/global-layout.module.css ***!
  \*********************************************/
/***/ ((module) => {

eval("// Exports\nmodule.exports = {\n\t\"container\": \"global-layout_container__CYKiv\",\n\t\"header\": \"global-layout_header__m2vgC\",\n\t\"main\": \"global-layout_main__wNLwd\",\n\t\"footer\": \"global-layout_footer__B9CYR\"\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvc3R5bGVzL2dsb2JhbC1sYXlvdXQubW9kdWxlLmNzcyIsIm1hcHBpbmdzIjoiQUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSIsInNvdXJjZXMiOlsid2VicGFjazovL3VpLW1haW4vLi9zcmMvc3R5bGVzL2dsb2JhbC1sYXlvdXQubW9kdWxlLmNzcz81ZWExIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIEV4cG9ydHNcbm1vZHVsZS5leHBvcnRzID0ge1xuXHRcImNvbnRhaW5lclwiOiBcImdsb2JhbC1sYXlvdXRfY29udGFpbmVyX19DWUtpdlwiLFxuXHRcImhlYWRlclwiOiBcImdsb2JhbC1sYXlvdXRfaGVhZGVyX19tMnZnQ1wiLFxuXHRcIm1haW5cIjogXCJnbG9iYWwtbGF5b3V0X21haW5fX3dOTHdkXCIsXG5cdFwiZm9vdGVyXCI6IFwiZ2xvYmFsLWxheW91dF9mb290ZXJfX0I5Q1lSXCJcbn07XG4iXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/styles/global-layout.module.css\n");

/***/ }),

/***/ "./src/components/global-layout.tsx":
/*!******************************************!*\
  !*** ./src/components/global-layout.tsx ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/link */ \"./node_modules/next/link.js\");\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _styles_global_layout_module_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../styles/global-layout.module.css */ \"./src/styles/global-layout.module.css\");\n/* harmony import */ var _styles_global_layout_module_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_global_layout_module_css__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\nconst GlobalLayout = ({ children })=>{\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        className: (_styles_global_layout_module_css__WEBPACK_IMPORTED_MODULE_2___default().container),\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"header\", {\n                className: (_styles_global_layout_module_css__WEBPACK_IMPORTED_MODULE_2___default().header),\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {\n                    href: \"/\",\n                    children: \"\\uD83D\\uDCD5 Book Lists\"\n                }, void 0, false, {\n                    fileName: \"C:\\\\Ezenac\\\\Class\\\\Ezenac\\\\1115\\\\ui-main\\\\src\\\\components\\\\global-layout.tsx\",\n                    lineNumber: 9,\n                    columnNumber: 9\n                }, undefined)\n            }, void 0, false, {\n                fileName: \"C:\\\\Ezenac\\\\Class\\\\Ezenac\\\\1115\\\\ui-main\\\\src\\\\components\\\\global-layout.tsx\",\n                lineNumber: 8,\n                columnNumber: 7\n            }, undefined),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"main\", {\n                className: (_styles_global_layout_module_css__WEBPACK_IMPORTED_MODULE_2___default().main),\n                children: children\n            }, void 0, false, {\n                fileName: \"C:\\\\Ezenac\\\\Class\\\\Ezenac\\\\1115\\\\ui-main\\\\src\\\\components\\\\global-layout.tsx\",\n                lineNumber: 11,\n                columnNumber: 7\n            }, undefined),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"footer\", {\n                children: \"Copyright \\xa9 Park Phillips\"\n            }, void 0, false, {\n                fileName: \"C:\\\\Ezenac\\\\Class\\\\Ezenac\\\\1115\\\\ui-main\\\\src\\\\components\\\\global-layout.tsx\",\n                lineNumber: 12,\n                columnNumber: 7\n            }, undefined)\n        ]\n    }, void 0, true, {\n        fileName: \"C:\\\\Ezenac\\\\Class\\\\Ezenac\\\\1115\\\\ui-main\\\\src\\\\components\\\\global-layout.tsx\",\n        lineNumber: 7,\n        columnNumber: 5\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (GlobalLayout);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy9nbG9iYWwtbGF5b3V0LnRzeCIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQUE2QjtBQUUwQjtBQUV2RCxNQUFNRSxlQUFlLENBQUMsRUFBRUMsUUFBUSxFQUEyQjtJQUN6RCxxQkFDRSw4REFBQ0M7UUFBSUMsV0FBV0osbUZBQWU7OzBCQUM3Qiw4REFBQ007Z0JBQU9GLFdBQVdKLGdGQUFZOzBCQUM3Qiw0RUFBQ0Qsa0RBQUlBO29CQUFDUSxNQUFNOzhCQUFLOzs7Ozs7Ozs7OzswQkFFbkIsOERBQUNDO2dCQUFLSixXQUFXSiw4RUFBVTswQkFBR0U7Ozs7OzswQkFDOUIsOERBQUNPOzBCQUFPOzs7Ozs7Ozs7Ozs7QUFHZDtBQUVBLGlFQUFlUixZQUFZQSxFQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vdWktbWFpbi8uL3NyYy9jb21wb25lbnRzL2dsb2JhbC1sYXlvdXQudHN4P2RlYTYiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IExpbmsgZnJvbSBcIm5leHQvbGlua1wiO1xyXG5pbXBvcnQgeyBSZWFjdE5vZGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHN0eWxlIGZyb20gXCIuLi9zdHlsZXMvZ2xvYmFsLWxheW91dC5tb2R1bGUuY3NzXCI7XHJcblxyXG5jb25zdCBHbG9iYWxMYXlvdXQgPSAoeyBjaGlsZHJlbiB9OiB7IGNoaWxkcmVuOiBSZWFjdE5vZGUgfSkgPT4ge1xyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGUuY29udGFpbmVyfT5cclxuICAgICAgPGhlYWRlciBjbGFzc05hbWU9e3N0eWxlLmhlYWRlcn0+XHJcbiAgICAgICAgPExpbmsgaHJlZj17XCIvXCJ9PvCfk5UgQm9vayBMaXN0czwvTGluaz5cclxuICAgICAgPC9oZWFkZXI+XHJcbiAgICAgIDxtYWluIGNsYXNzTmFtZT17c3R5bGUubWFpbn0+e2NoaWxkcmVufTwvbWFpbj5cclxuICAgICAgPGZvb3Rlcj5Db3B5cmlnaHQgJmNvcHk7IFBhcmsgUGhpbGxpcHM8L2Zvb3Rlcj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBHbG9iYWxMYXlvdXQ7XHJcbiJdLCJuYW1lcyI6WyJMaW5rIiwic3R5bGUiLCJHbG9iYWxMYXlvdXQiLCJjaGlsZHJlbiIsImRpdiIsImNsYXNzTmFtZSIsImNvbnRhaW5lciIsImhlYWRlciIsImhyZWYiLCJtYWluIiwiZm9vdGVyIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./src/components/global-layout.tsx\n");

/***/ }),

/***/ "./src/pages/_app.tsx":
/*!****************************!*\
  !*** ./src/pages/_app.tsx ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ App)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/styles/globals.css */ \"./src/styles/globals.css\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _components_global_layout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/components/global-layout */ \"./src/components/global-layout.tsx\");\n\n\n\n//이거 그럼 interface로 만들어놓고 extends로 해도 가능함? 가능하지 않을까 싶다고 함\nfunction App({ pageProps, Component }) {\n    const getLayout = Component.getLayout ?? ((page)=>page);\n    // const router = useRouter();\n    // const handleNavigateTest = () => {\n    //   router.push(\"/test\");\n    //   // router.replace(\"/test\");\n    //   // router.back();\n    // };\n    // useEffect(() => {\n    //   router.prefetch(\"/test\");\n    // }, []);\n    return(// <div>\n    //   <header>Header</header>\n    //   {/* <header>\n    //     <Link href={\"/\"}>Home</Link>\n    //     &nbsp;\n    //     <Link href={\"/search\"} prefetch={false}>\n    //       Search\n    //     </Link>\n    //     &nbsp;\n    //     <Link href={\"/book\"}>Book</Link>\n    //     <div>\n    //       <button onClick={handleNavigateTest}>/test로 이동</button>\n    //     </div>\n    //   </header> */}\n    //   <main>\n    //     <Component {...pageProps} />\n    //   </main>\n    //   <footer>Footer</footer>\n    // </div>\n    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_global_layout__WEBPACK_IMPORTED_MODULE_2__[\"default\"], {\n        children: getLayout(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n            ...pageProps\n        }, void 0, false, {\n            fileName: \"C:\\\\Ezenac\\\\Class\\\\Ezenac\\\\1115\\\\ui-main\\\\src\\\\pages\\\\_app.tsx\",\n            lineNumber: 49,\n            columnNumber: 30\n        }, this))\n    }, void 0, false, {\n        fileName: \"C:\\\\Ezenac\\\\Class\\\\Ezenac\\\\1115\\\\ui-main\\\\src\\\\pages\\\\_app.tsx\",\n        lineNumber: 49,\n        columnNumber: 5\n    }, this));\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvcGFnZXMvX2FwcC50c3giLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUE4QjtBQUN3QjtBQVV0RCx3REFBd0Q7QUFFekMsU0FBU0MsSUFBSSxFQUMxQkMsU0FBUyxFQUNUQyxTQUFTLEVBQ29DO0lBQzdDLE1BQU1DLFlBQVlELFVBQVVDLFNBQVMsSUFBSyxFQUFDQyxPQUFvQkEsSUFBRztJQUNsRSw4QkFBOEI7SUFDOUIscUNBQXFDO0lBQ3JDLDBCQUEwQjtJQUMxQixnQ0FBZ0M7SUFDaEMsc0JBQXNCO0lBQ3RCLEtBQUs7SUFFTCxvQkFBb0I7SUFDcEIsOEJBQThCO0lBQzlCLFVBQVU7SUFDVixPQUNFLFFBQVE7SUFDUiw0QkFBNEI7SUFDNUIsaUJBQWlCO0lBQ2pCLG1DQUFtQztJQUNuQyxhQUFhO0lBQ2IsK0NBQStDO0lBQy9DLGVBQWU7SUFDZixjQUFjO0lBQ2QsYUFBYTtJQUNiLHVDQUF1QztJQUN2QyxZQUFZO0lBQ1osZ0VBQWdFO0lBQ2hFLGFBQWE7SUFDYixrQkFBa0I7SUFDbEIsV0FBVztJQUNYLG1DQUFtQztJQUNuQyxZQUFZO0lBQ1osNEJBQTRCO0lBQzVCLFNBQVM7a0JBQ1QsOERBQUNMLGlFQUFZQTtrQkFBRUksd0JBQVUsOERBQUNEO1lBQVcsR0FBR0QsU0FBUzs7Ozs7Ozs7Ozs7QUFFckQiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly91aS1tYWluLy4vc3JjL3BhZ2VzL19hcHAudHN4P2Y5ZDYiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFwiQC9zdHlsZXMvZ2xvYmFscy5jc3NcIjtcbmltcG9ydCBHbG9iYWxMYXlvdXQgZnJvbSBcIkAvY29tcG9uZW50cy9nbG9iYWwtbGF5b3V0XCI7XG5pbXBvcnQgU2VhcmNoYWJsZUxheW91dCBmcm9tIFwiQC9jb21wb25lbnRzL3NlYXJjaGFibGUtbGF5b3V0XCI7XG5pbXBvcnQgdHlwZSB7IEFwcFByb3BzIH0gZnJvbSBcIm5leHQvYXBwXCI7XG5pbXBvcnQgeyBOZXh0UGFnZSB9IGZyb20gXCJuZXh0XCI7XG5pbXBvcnQgeyBSZWFjdE5vZGUgfSBmcm9tIFwicmVhY3RcIjtcblxuLy9OZXh0UGFnZeudvOuKlCDtg4DsnoXsnbQg67CY65Oc7IucIOyhtOyerO2VtOyVvO2VqC5cbnR5cGUgTmV4dFBhZ2VXaXRoTGF5b3V0ID0gTmV4dFBhZ2UgJiB7XG4gIGdldExheW91dDogKHBhZ2U6IFJlYWN0Tm9kZSkgPT4gUmVhY3ROb2RlO1xufTtcbi8v7J206rGwIOq3uOufvCBpbnRlcmZhY2XroZwg66eM65Ok7Ja064aT6rOgIGV4dGVuZHProZwg7ZW064+EIOqwgOuKpe2VqD8g6rCA64ql7ZWY7KeAIOyViuydhOq5jCDsi7bri6Tqs6Ag7ZWoXG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEFwcCh7XG4gIHBhZ2VQcm9wcyxcbiAgQ29tcG9uZW50LFxufTogQXBwUHJvcHMgJiB7IENvbXBvbmVudDogTmV4dFBhZ2VXaXRoTGF5b3V0IH0pIHtcbiAgY29uc3QgZ2V0TGF5b3V0ID0gQ29tcG9uZW50LmdldExheW91dCA/PyAoKHBhZ2U6IFJlYWN0Tm9kZSkgPT4gcGFnZSk7XG4gIC8vIGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xuICAvLyBjb25zdCBoYW5kbGVOYXZpZ2F0ZVRlc3QgPSAoKSA9PiB7XG4gIC8vICAgcm91dGVyLnB1c2goXCIvdGVzdFwiKTtcbiAgLy8gICAvLyByb3V0ZXIucmVwbGFjZShcIi90ZXN0XCIpO1xuICAvLyAgIC8vIHJvdXRlci5iYWNrKCk7XG4gIC8vIH07XG5cbiAgLy8gdXNlRWZmZWN0KCgpID0+IHtcbiAgLy8gICByb3V0ZXIucHJlZmV0Y2goXCIvdGVzdFwiKTtcbiAgLy8gfSwgW10pO1xuICByZXR1cm4gKFxuICAgIC8vIDxkaXY+XG4gICAgLy8gICA8aGVhZGVyPkhlYWRlcjwvaGVhZGVyPlxuICAgIC8vICAgey8qIDxoZWFkZXI+XG4gICAgLy8gICAgIDxMaW5rIGhyZWY9e1wiL1wifT5Ib21lPC9MaW5rPlxuICAgIC8vICAgICAmbmJzcDtcbiAgICAvLyAgICAgPExpbmsgaHJlZj17XCIvc2VhcmNoXCJ9IHByZWZldGNoPXtmYWxzZX0+XG4gICAgLy8gICAgICAgU2VhcmNoXG4gICAgLy8gICAgIDwvTGluaz5cbiAgICAvLyAgICAgJm5ic3A7XG4gICAgLy8gICAgIDxMaW5rIGhyZWY9e1wiL2Jvb2tcIn0+Qm9vazwvTGluaz5cbiAgICAvLyAgICAgPGRpdj5cbiAgICAvLyAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e2hhbmRsZU5hdmlnYXRlVGVzdH0+L3Rlc3TroZwg7J2064+ZPC9idXR0b24+XG4gICAgLy8gICAgIDwvZGl2PlxuICAgIC8vICAgPC9oZWFkZXI+ICovfVxuICAgIC8vICAgPG1haW4+XG4gICAgLy8gICAgIDxDb21wb25lbnQgey4uLnBhZ2VQcm9wc30gLz5cbiAgICAvLyAgIDwvbWFpbj5cbiAgICAvLyAgIDxmb290ZXI+Rm9vdGVyPC9mb290ZXI+XG4gICAgLy8gPC9kaXY+XG4gICAgPEdsb2JhbExheW91dD57Z2V0TGF5b3V0KDxDb21wb25lbnQgey4uLnBhZ2VQcm9wc30gLz4pfTwvR2xvYmFsTGF5b3V0PlxuICApO1xufVxuIl0sIm5hbWVzIjpbIkdsb2JhbExheW91dCIsIkFwcCIsInBhZ2VQcm9wcyIsIkNvbXBvbmVudCIsImdldExheW91dCIsInBhZ2UiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/pages/_app.tsx\n");

/***/ }),

/***/ "./src/styles/globals.css":
/*!********************************!*\
  !*** ./src/styles/globals.css ***!
  \********************************/
/***/ (() => {



/***/ }),

/***/ "next/dist/compiled/next-server/pages.runtime.dev.js":
/*!**********************************************************************!*\
  !*** external "next/dist/compiled/next-server/pages.runtime.dev.js" ***!
  \**********************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/pages.runtime.dev.js");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "react/jsx-runtime":
/*!************************************!*\
  !*** external "react/jsx-runtime" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/@swc"], () => (__webpack_exec__("./src/pages/_app.tsx")));
module.exports = __webpack_exports__;

})();