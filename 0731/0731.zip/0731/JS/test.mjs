let test = "Hi! JS";
console.log(test);