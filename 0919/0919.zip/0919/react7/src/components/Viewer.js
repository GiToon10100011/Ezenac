import React from "react";

const Viewer = () => {
  return <div>Viewer</div>;
};

export default Viewer;
