import React from "react";

const Chart = () => {
  return <div></div>;
};

export default Chart;
