import { createRoot } from "react-dom/client";
// import App from "./App.tsx";
import App from "./Modal2.tsx";

createRoot(document.getElementById("root")!).render(<App />);
