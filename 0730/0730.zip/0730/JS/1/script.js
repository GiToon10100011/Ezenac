// let test1 = "mon";
// test1 = "tue";

// const wrapper = document.querySelector("#wrapper");

// const num1 = 1;
// const num2 = 2;

// const sum = num1 + num2;

// console.log(typeof(sum));

// const str1 = "집";
// const str2 = "가고 싶다";
// console.log(typeof str1+str2);

const num = 1000;
const str = "원";

const counter = num + str;

const num1 = 1000;
const str1 = "2000";

const counter1 = num1 + str1;
console.log(counter1);

prompt("인증번호를 입력하세요.");

