import React from "react";

const ServerComponent = () => {
  console.log("Server Component");
  return <div></div>;
};

export default ServerComponent;
