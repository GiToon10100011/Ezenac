import React from "react";

const Tv = () => {
  return <div>tv</div>;
};

export default Tv;
