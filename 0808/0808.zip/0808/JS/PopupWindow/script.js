const btn = document.querySelector("button");

btn.addEventListener("click", () => {
  window.open("./notice.html", "popup", "width = 600 height = 500");
})

