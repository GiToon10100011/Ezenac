import { ITheme } from "styled-components";

export const defaultTheme: ITheme = {
  bgColor: "#3f8cf2",
  boardColor: "#dadfe9",
  cardColor: "#fff",
};
