enum Role {
  ADMIN = 0,
  USER = 1,
  GUEST = 2,
}

export const user1 = {
  name: "염동훈",
  role: Role.ADMIN,
};
export const user2 = {
  name: "이승연",
  role: Role.USER,
};
export const user3 = {
  name: "정보경",
  role: Role.GUEST,
};
