const API_KEY = "9a5e256f334bf8b56aa0d722ac419f38";

export default { API_KEY };
