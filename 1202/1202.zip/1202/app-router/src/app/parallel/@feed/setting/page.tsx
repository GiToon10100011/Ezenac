import React from "react";

const Page = () => {
  return <div>@feed/settings</div>;
};

export default Page;
