import React from "react";

const Page = () => {
  return <div>parallel</div>;
};

export default Page;
