import React from "react";

const Page = () => {
  return <div>Settings Page</div>;
};

export default Page;
