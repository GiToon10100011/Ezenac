import React from "react";

const Movie = () => {
  return <div></div>;
};

export default Movie;
