import { createStore } from "redux";
import Reducer from "./Reducer";

let store = createStore(Reducer);

export default store;
