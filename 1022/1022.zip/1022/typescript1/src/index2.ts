const num: number = 2;
