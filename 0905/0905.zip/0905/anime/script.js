anime({
  targets: ".svg2 path",
  strokeDashoffset: [anime.setDashoffset, 100],
  duration: 5000,
  easing: "easeInOutSine",
  loop: true,
  direction: "alternate",
});
