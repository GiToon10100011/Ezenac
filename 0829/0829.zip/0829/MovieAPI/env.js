const API_KEY = "2693c8b097c1f6ba5c77aeded9dd160c";
export default { API_KEY };
// export {API_KEY};
